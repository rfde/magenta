README

Algorithm:	Magenta
Submitter:	Deutsche Telekom AG (represented by Dr. Klaus Huber)
--------------------------------------------------------------------

"Test Values: Known Answer Tests and Monte Carlo Tests"

Files in this directory:

Known Answer Tests:
	ecb_vk.txt	- variable key test values
	ecb_vt.txt	- variable text test values
	ecb_int.txt	- intermediate round test values (see file for 
			  description of tests)
	ecb_tbl.txt	- table test values (see file for description of tests)

Monte Carlo Tests:
	ecb_e_m.txt	- ECB encrypt mode test values
	ecb_d_m.txt	- ECB decrypt mode test values
	cbc_e_m.txt	- CBC encrypt mode test values
	cbc_d_m.txt	- CBC decrypt mode test values
-
